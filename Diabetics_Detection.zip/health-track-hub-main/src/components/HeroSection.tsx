import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Activity, Shield, TrendingUp, Heart } from "lucide-react";

const HeroSection = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/10 py-20 lg:py-32">
      <div className="container relative z-10">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-2 text-sm text-primary">
            <Heart className="h-4 w-4" />
            Advanced Health Monitoring
          </div>
          
          <h1 className="mb-6 text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
            Take Control of Your{" "}
            <span className="text-primary">Diabetes Risk</span>
          </h1>
          
          <p className="mb-10 text-lg text-muted-foreground sm:text-xl">
            Monitor your health metrics, assess diabetes risk factors, and track your progress over time 
            with our comprehensive health tracking platform.
          </p>
          
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link to="/signup">
              <Button size="lg" className="gap-2 text-lg">
                <Activity className="h-5 w-5" />
                Start Assessment
              </Button>
            </Link>
            <Link to="/login">
              <Button size="lg" variant="outline" className="gap-2 text-lg">
                View Dashboard
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="mt-20 grid gap-8 sm:grid-cols-3">
          <div className="rounded-xl border bg-card p-6 text-center shadow-sm">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Activity className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-2 font-semibold text-card-foreground">Risk Assessment</h3>
            <p className="text-sm text-muted-foreground">
              Comprehensive diabetes risk evaluation based on clinical factors
            </p>
          </div>
          
          <div className="rounded-xl border bg-card p-6 text-center shadow-sm">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <TrendingUp className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-2 font-semibold text-card-foreground">Track Progress</h3>
            <p className="text-sm text-muted-foreground">
              Monitor glucose levels, BMI, and other vital health metrics
            </p>
          </div>
          
          <div className="rounded-xl border bg-card p-6 text-center shadow-sm">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <h3 className="mb-2 font-semibold text-card-foreground">Secure & Private</h3>
            <p className="text-sm text-muted-foreground">
              Your health data is encrypted and protected at all times
            </p>
          </div>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/5 blur-3xl" />
      <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-secondary/10 blur-3xl" />
    </section>
  );
};

export default HeroSection;
