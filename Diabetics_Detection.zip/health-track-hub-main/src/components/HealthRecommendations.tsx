import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Apple, 
  Dumbbell, 
  Moon, 
  Droplets, 
  HeartPulse, 
  Scale, 
  Stethoscope,
  AlertCircle,
  CheckCircle2,
  Info
} from "lucide-react";

interface HealthRecommendationsProps {
  riskLevel: "Low" | "Moderate" | "High";
  riskScore: number;
  factors: {
    highBMI: boolean;
    highGlucose: boolean;
    highBP: boolean;
    familyHistory: boolean;
    cardiovascular: boolean;
    ageRisk: boolean;
  };
}

const HealthRecommendations = ({ riskLevel, riskScore, factors }: HealthRecommendationsProps) => {
  const generalTips = [
    {
      icon: Apple,
      title: "Healthy Diet",
      description: "Focus on whole grains, vegetables, lean proteins, and limit processed foods and sugary drinks.",
      priority: "essential",
    },
    {
      icon: Dumbbell,
      title: "Regular Exercise",
      description: "Aim for at least 150 minutes of moderate aerobic activity weekly, plus strength training.",
      priority: "essential",
    },
    {
      icon: Moon,
      title: "Quality Sleep",
      description: "Get 7-9 hours of sleep per night. Poor sleep can affect blood sugar regulation.",
      priority: "important",
    },
    {
      icon: Droplets,
      title: "Stay Hydrated",
      description: "Drink plenty of water throughout the day. Avoid sugary beverages.",
      priority: "important",
    },
  ];

  const specificRecommendations = [];

  if (factors.highBMI) {
    specificRecommendations.push({
      icon: Scale,
      title: "Weight Management",
      description: "Losing 5-10% of body weight can significantly reduce diabetes risk. Consider consulting a dietitian.",
      severity: "high",
    });
  }

  if (factors.highGlucose) {
    specificRecommendations.push({
      icon: Droplets,
      title: "Monitor Blood Sugar",
      description: "Your glucose levels indicate pre-diabetes. Regular monitoring and dietary changes are crucial.",
      severity: "high",
    });
  }

  if (factors.highBP) {
    specificRecommendations.push({
      icon: HeartPulse,
      title: "Blood Pressure Control",
      description: "Reduce sodium intake, manage stress, and consider medication if prescribed by your doctor.",
      severity: "high",
    });
  }

  if (factors.familyHistory) {
    specificRecommendations.push({
      icon: Stethoscope,
      title: "Regular Screenings",
      description: "With family history, get annual diabetes screenings. Early detection is key to prevention.",
      severity: "moderate",
    });
  }

  if (factors.cardiovascular) {
    specificRecommendations.push({
      icon: HeartPulse,
      title: "Heart Health Focus",
      description: "Monitor cholesterol levels, follow a heart-healthy diet, and take prescribed medications.",
      severity: "high",
    });
  }

  if (factors.ageRisk) {
    specificRecommendations.push({
      icon: Info,
      title: "Age-Related Prevention",
      description: "Risk increases with age. Maintain regular health check-ups and stay physically active.",
      severity: "moderate",
    });
  }

  const getActionPlan = () => {
    if (riskLevel === "High") {
      return {
        title: "Immediate Action Recommended",
        description: "Based on your assessment, we recommend consulting a healthcare provider within the next 2 weeks.",
        actions: [
          "Schedule an appointment with your doctor",
          "Request a comprehensive metabolic panel",
          "Consider referral to an endocrinologist",
          "Begin lifestyle modifications immediately",
        ],
      };
    } else if (riskLevel === "Moderate") {
      return {
        title: "Preventive Measures Advised",
        description: "Your risk factors are manageable with lifestyle changes and regular monitoring.",
        actions: [
          "Implement dietary changes gradually",
          "Start a regular exercise routine",
          "Monitor blood sugar quarterly",
          "Schedule annual comprehensive check-ups",
        ],
      };
    } else {
      return {
        title: "Maintain Healthy Habits",
        description: "Your risk is low, but continuing healthy practices will help maintain this status.",
        actions: [
          "Continue balanced nutrition",
          "Stay physically active",
          "Get annual health screenings",
          "Monitor any changes in health",
        ],
      };
    }
  };

  const actionPlan = getActionPlan();

  return (
    <div className="space-y-6">
      {/* Action Plan */}
      <Card className={`border-2 ${
        riskLevel === "High" ? "border-destructive bg-destructive/5" :
        riskLevel === "Moderate" ? "border-yellow-500 bg-yellow-500/5" :
        "border-green-500 bg-green-500/5"
      }`}>
        <CardHeader>
          <div className="flex items-center gap-3">
            {riskLevel === "High" ? (
              <AlertCircle className="h-6 w-6 text-destructive" />
            ) : riskLevel === "Moderate" ? (
              <Info className="h-6 w-6 text-yellow-600" />
            ) : (
              <CheckCircle2 className="h-6 w-6 text-green-600" />
            )}
            <div>
              <CardTitle>{actionPlan.title}</CardTitle>
              <CardDescription className="mt-1">{actionPlan.description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {actionPlan.actions.map((action, index) => (
              <li key={index} className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                {action}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Specific Recommendations */}
      {specificRecommendations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Personalized Recommendations</CardTitle>
            <CardDescription>Based on your specific risk factors</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {specificRecommendations.map((rec, index) => (
              <div key={index} className="flex gap-4 rounded-lg border p-4">
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${
                  rec.severity === "high" ? "bg-destructive/10" : "bg-yellow-500/10"
                }`}>
                  <rec.icon className={`h-5 w-5 ${
                    rec.severity === "high" ? "text-destructive" : "text-yellow-600"
                  }`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold">{rec.title}</h4>
                    <Badge variant={rec.severity === "high" ? "destructive" : "secondary"}>
                      {rec.severity === "high" ? "Priority" : "Important"}
                    </Badge>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{rec.description}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* General Health Tips */}
      <Card>
        <CardHeader>
          <CardTitle>General Health Tips</CardTitle>
          <CardDescription>Foundational habits for diabetes prevention</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-2">
            {generalTips.map((tip, index) => (
              <div key={index} className="flex gap-3 rounded-lg border p-4">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                  <tip.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="font-semibold">{tip.title}</h4>
                  <p className="mt-1 text-sm text-muted-foreground">{tip.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <p className="text-center text-xs text-muted-foreground">
        <strong>Disclaimer:</strong> These recommendations are for informational purposes only and do not constitute medical advice. 
        Always consult with a qualified healthcare provider for personalized medical guidance.
      </p>
    </div>
  );
};

export default HealthRecommendations;
